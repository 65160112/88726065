<template>
    <div>
        <nav class="flex-nav">
            <div class="container1">
                <div class="grid">
                    <div class="column-xs-9 column-md-8">
                        <p id="logo">Switzerland<span id="highlight">.</span></p>
                    </div>
                    <div class="column-xs-3 column-md-4">
                        <li class="search-li">
                            <form class="search-form" @submit.prevent="searchLocations" action="#" method="get">
                                <input type="search" v-model="searchQuery" name="search" id="search"
                                    placeholder="Search..." @keydown.enter="searchLocations">
                                <button type="submit">Search</button>
                            </form>
                        </li>
                    </div>
                </div>
            </div>
        </nav>
        <main>
            <header class="header">
                <span>{{ filteredLocations.length }} check-in locations</span>
                <h1>Travel to Switzerland</h1>
                <p>Explore the breathtaking beauty of Switzerland and its iconic destinations.</p>
            </header>
            <div class="owl-carousel owl-theme">
                <div v-for="(location, index) in filteredLocations" :key="index" class="item">
                    <img :src="location.image" :alt="location.alt">
                    <div class="overlay">
                        <span>{{ location.name }}</span>
                        <div class="content">
                            <h2>{{ location.title }}</h2>
                            <p>{{ location.description }}</p>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</template>

<script>
export default {
    data() {
        return {
            locations: [
                {
                    name: 'Interlaken',
                    title: 'Jungfrau',
                    description: '1 Popular places',
                    image: 'https://res.klook.com/image/upload/fl_lossy.progressive,q_85/c_fill,w_1000/v1637650304/blog/mmx2ys7wyaidvppnettl.webp',
                    alt: 'Interlaken'
                },
                {
                    name: 'Interlaken',
                    title: 'Lake Brienz',
                    description: '2 Popular places',
                    image: 'https://res.klook.com/image/upload/fl_lossy.progressive,q_85/c_fill,w_1000/v1637650427/blog/dot7vv4jn9szietxk65e.webp',
                    alt: 'Interlaken'
                }, {
                    name: 'Zermatt',
                    title: 'Matternhorn',
                    description: '3 Popular places',
                    image: 'https://res.klook.com/image/upload/fl_lossy.progressive,q_85/c_fill,w_1000/v1637650606/blog/uoczj6etzvqtvmyom490.webp',
                    alt: 'Interlaken'
                }, {
                    name: 'Luzern',
                    title: 'Chapel Bridge',
                    description: '4 Popular places',
                    image: 'https://res.klook.com/image/upload/fl_lossy.progressive,q_85/c_fill,w_1000/v1637650646/blog/cdyif4n7rqkjqida8h0f.webp',
                    alt: 'Interlaken'
                }, {
                    name: 'Zurich',
                    title: 'Lindenhof',
                    description: '5 Popular places',
                    image: 'https://res.klook.com/image/upload/fl_lossy.progressive,q_85/c_fill,w_1000/v1637650911/blog/nmydhpuwjzwemhyirspj.webp',
                    alt: 'Interlaken'
                }, {
                    name: 'Zurich',
                    title: 'Fraumunster Church',
                    description: '6 Popular places',
                    image: 'https://res.klook.com/image/upload/fl_lossy.progressive,q_85/c_fill,w_1000/v1637651112/blog/gtcevkmzdimn49vfeqk8.webp',
                    alt: 'Interlaken'
                }, {
                    name: 'Bern',
                    title: 'Zytglogge Clock Tower',
                    description: '7 Popular places',
                    image: 'https://res.klook.com/image/upload/fl_lossy.progressive,q_85/c_fill,w_1000/v1637654799/blog/yvldrpxhwdgtc1iuihmz.webp',
                    alt: 'Interlaken'
                }, {
                    name: 'Lausanne',
                    title: 'Cathédrale Notre-Dame de Lausanne',
                    description: '8 Popular places',
                    image: 'https://res.klook.com/image/upload/fl_lossy.progressive,q_85/c_fill,w_1000/v1637655004/blog/lk9aw1gz2v0ts0c9fpj7.webp',
                    alt: 'Interlaken'
                }, {
                    name: 'Geneva',
                    title: 'The Flower Clock',
                    description: '9 Popular places',
                    image: 'https://res.klook.com/image/upload/fl_lossy.progressive,q_85/c_fill,w_1000/v1637655080/blog/xu2rg7z6qfcfzopkdzsq.webp',
                    alt: 'Interlaken'
                }, {
                    name: 'Engelberg',
                    title: 'Mount Titlis',
                    description: '10 Popular places',
                    image: 'https://res.klook.com/image/upload/fl_lossy.progressive,q_85/c_fill,w_1000/v1637655501/blog/uixiewld0ckq8a2ugbj4.webp',
                    alt: 'Interlaken'
                },
            ],
            searchQuery: '',
        };
    },
    computed: {
        filteredLocations() {
            if (!this.searchQuery) {
                return this.locations;
            }
            const query = this.searchQuery.toLowerCase();
            return this.locations.filter(location =>
                location.name.toLowerCase().includes(query) ||
                location.title.toLowerCase().includes(query) ||
                location.description.toLowerCase().includes(query)
            );
        }
    },
    methods: {
        searchLocations() {
            
            console.log('Search query:', this.searchQuery);
            
        }
    }
};
</script>

<style scoped>
body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
}

.container1 {
    width: 90%;
    margin: 0 auto;
}

.flex-nav {
    background-color: #ffffff;
    color: #000000;
    padding: 10px 0;
}

.grid {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.column-xs-9 {
    flex: 0 0 75%;
}

.column-md-8 {
    flex: 0 0 66.66667%;
}

.column-xs-3 {
    flex: 0 0 25%;
    font-size: 20px;
}

.column-md-4 {
    flex: 0 0 33.33333%;
    font-size: 20px;
}

#logo {
    font-size: 30px;
    font-weight: bold;
}

#highlight {
    color: #f50404;
}

.toggle-nav {
    display: none;
}

ul {
    list-style-type: none;
    padding: 0;
}

li {
    display: inline;
    margin-right: 20px;
}

a {
    color: #000000;
    text-decoration: none;
}

a:hover {
    text-decoration: underline;
}

/* CSS Styles for Search Input */
.search-form {
    position: relative;
    margin-right: 20px;
}

#search {
    padding: 8px 10px;
    border: 1px solid #ccc;
    border-radius: 20px;
    font-size: 14px;
    width: 180px;
}

#search:focus {
    outline: none;
    border-color: #66afe9;
    box-shadow: 0 0 5px rgba(102, 175, 233, 0.6);
}

button[type="submit"] {
    background-color: #66afe9;
    border: none;
    color: #fff;
    padding: 8px 15px;
    border-radius: 20px;
    cursor: pointer;
    transition: background-color 0.3s;
    margin-right: 20px;
}

button[type="submit"]:hover {
    background-color: #4c8bf5;
}

@media screen and (max-width: 600px) {
    #search {
        width: 100px;
    }
}

.nav-links {
    display: flex;
    align-items: center;
    margin: 10;
    padding: 0;
}

.nav-links li {
    list-style: none;
    margin-right: 20px;
}

.search-li {
    margin-left: 20px;
}

* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}

body {
    font-family: "Inter", sans-serif;
    color: #111;
    background: #f5f6f8;
}

main {
    width: min(980px, 60%);
    margin: 0 auto;
    min-height: 100vh;
    display: flex;
    flex-direction: column;
    justify-content: center;
    padding-block: min(10vh, 2em);

    .header {
        margin-bottom: 55px;

        h1 {
            font-weight: 800;
            font-size: 3rem;
            margin: 5px -5px 15px;
        }

        span {
            text-transform: uppercase;
            letter-spacing: 1px;
            display: inline-block;
            font-weight: 700;
            font-size: 14px;
            color: #000000;
        }

        p {
            max-width: min(40ch, 100% - 2rem);
            line-height: 1.6;
            color: #070606;
        }
    }

    .item {
        width: 100%;
        height: 400px;
        position: relative;
        border-radius: 12px;
        overflow: hidden;
        margin-bottom: 25px;

        img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            position: absolute;
            inset: 0;
        }

        .overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            padding: 28px 25px;
            color: #fff;
            background: rgb(0, 0, 0);
            background: linear-gradient(0deg,
                    #020024 0%,
                    #000032a1 3%,
                    #17d9ff00 100%);
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            align-items: flex-start;

            span {
                background: rgba(255, 253, 253, 0.25);
                backdrop-filter: blur(4px);
                -webkit-backdrop-filter: blur(4px);
                border-radius: 60px;
                padding: 10px 20px;
                display: inline-block;
            }

            >div {
                h2 {
                    letter-spacing: 0.5px;
                    margin-bottom: 5px;
                }
            }
        }
    }
}

.owl-nav {
    position: absolute;
    top: -100px;
    right: 0;

    button {
        background: #fff !important;
        width: 45px;
        height: 45px;
        font-size: 25px !important;
        box-shadow: 0px 0px 17px #00000005;
        border-radius: 50%;

        &:nth-of-type(1) {
            margin-right: 13px;
        }
    }
}
</style>