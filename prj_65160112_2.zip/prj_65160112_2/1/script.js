document.addEventListener('DOMContentLoaded', function () {
    const searchForm = document.querySelector('.search-form');
    const items = document.querySelectorAll('.item');

    function filterItems(searchInput) {
        items.forEach(function (item) {
            const spanText = item.querySelector('.overlay span').textContent.trim().toLowerCase();
            if (spanText.includes(searchInput)) {
                item.style.display = 'block';
            } else {
                item.style.display = 'none';
            }
        });
    }
    searchForm.addEventListener('click', function (event) {
        event.preventDefault();
        const searchInput = document.getElementById('search').value.trim().toLowerCase();
        filterItems(searchInput);
    });

    items.forEach(function (item) {
        const readMoreBtn = item.querySelector('.read-more-btn');
        readMoreBtn.addEventListener('click', function () {
            toggleContentVisibility(item);
        });
    });
});

